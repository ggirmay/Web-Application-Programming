package Servlet2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class ValidateFilter
 */
@WebFilter(
		urlPatterns= {"/Check"},
		servletNames= {"ContactUs"})
public class ValidateFilter implements Filter {
	int count =0;
   

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
		
		//System.out.println("In filter.");//check sequence.
		HttpServletRequest req =  (HttpServletRequest) request;
		String aname = req.getParameter("firstname");
		String agender = req.getParameter("gender");
		String acategory = req.getParameter("category");
		String amessage = req.getParameter("message");
		String amsg = null;
		
		
//		 if (aname == "") {
//		 
//		 amsg = "Name is Missing"; }
//		 
//		 if (agender == "") {
//		 
//		 amsg = "Gender is Missing"; } 
//		 if (acategory == "") {
//		 
//		 amsg = "Category is Missing"; } 
//		  if (amessage == "") {
//	 
//	amsg = "Message is Missing"; }
// 
//		 else
		if (aname == "" | agender == "" | amessage == "" | acategory == "" ) {
			//System.out.println("empty");
			//out.print("Invalid input");
			RequestDispatcher rd = request.getRequestDispatcher("ContactUs");
			 request.setAttribute("msg", "Please fill all ");
			   rd.forward(request, response);
			}
		else {
					// pass the request along the filter chain
		chain.doFilter(request, response); 
		}
		System.out.println(count++);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
