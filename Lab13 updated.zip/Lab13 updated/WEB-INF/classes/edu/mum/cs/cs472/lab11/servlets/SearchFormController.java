package edu.mum.cs.cs472.lab11.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.mum.cs.cs472.lab11.daos.ContactsDAO;
import edu.mum.cs.cs472.lab11.model.ContactFormData;

/**
 * Servlet implementation class SearchFormController
 */
@WebServlet("/SearchFormController")
public class SearchFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchFormController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("search");
		ContactsDAO contacts=new ContactsDAO();
		List<ContactFormData> list=new ArrayList<ContactFormData>(); 
		list=contacts.getContactFormData(name);
//		request.setAttribute("searchResult", list);
//		request.getRequestDispatcher("/Filtered-browse-messages.jsp").forward(request, response);
		
		request.setAttribute("contactMessages", list);
		request.getRequestDispatcher("/browse-messages.jsp").forward(request, response);
		
//		doGet(request, response);
	}

}
