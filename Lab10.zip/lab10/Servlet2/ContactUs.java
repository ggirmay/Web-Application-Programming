//package Servlet;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//public class HelloServlet extends HttpServlet {
//	
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		//System.out.println("Hello World");
//
//		//response.getWriter().append("Served at: ").append(request.getContextPath());
//		//String s= request.getParameter ();
//		
//		PrintWriter out =response.getWriter();
//		out.println("Hello World");
//	}
//
//}


package Servlet2;
 
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * Servlet implementation class ContactUs
 */
@WebServlet("/ContactUs")
public class ContactUs extends HttpServlet {
    private static final long serialVersionUID = 1L;
    int counter;
        
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactUs() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init(ServletConfig config) throws ServletException{
    	counter=0;
    }
 
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	counter++;
        response.setContentType("text/html");
        PrintWriter printWriter  = response.getWriter();
        if(request.getAttribute("msg") == null) {
        	printWriter.println("");
        }else
        	printWriter.println(request.getAttribute("msg"));
       
        printWriter.println("<head>\r\n" + 
        		"<style>\r\n" + 
        		"ul {\r\n" + 
        		"  list-style-type: none;\r\n" + 
        		"  margin: 0;\r\n" + 
        		"  padding: 10px;\r\n" +
        		"  color: white;\r\n" +
        		" background-color: black;\r\n"+
        		"}\r\n" + 
        		"\r\n" + 
        		"li {\r\n" + 
        		"  display: inline;\r\n" +
        		"  color: white;\r\n" +
        		"}\r\n" + 
				/*
				 * "li a {\r\n" + "display: block;\r\\n" + "color: white;\r\n" +
				 * "text-align: center;\r\n"+ "padding: 14px 16px;\r\n"+
				 * " text-decoration: none;}\r\n"+
				 */
        			
        		
        		"</style>\r\n" + 
        		"</head>"+ 
        		"<header>"+
        		"<ul>"+
        		  "<li>CS472-WAP:::Lab10</li>\t"+
        		  "<li><a href=\"#home\">Home</a></li>\t"+
        		  "<li><a href=\"#about\">About</a></li>\t"+
        		  "<li><a href=\"#contact\">Contact Us</a></li>\t"+
        		  "<li style=\"float:right\">"+
        		  
                  "<form action=\"action_page.php\">"+
        	      "<input type=\"text\" placeholder=\"Search\" name=\"search\">"+
        	      "<button type=\"submit\">Submit</button>"+
        	      "</form>"+
        		  
        		  
        		  "</li>"+
        		  "</ul>"+
        		  "</header>"+      		
        		  "<h1>Customer Contact Information </h1>" +
        		  
        		  
        		  "<form action = \"Check\">" + // will go to @check in Validate
        		  "*Name:<br>" +
        		  "<input type=\"text\" name=\"firstname\"><br><br>" +
        		         		        		 
        		  "*Gender:<br><br>" +
        		  "<input type=\"radio\" name=\"gender\" value=\"male\" checked> Male"+
        		  "<input type=\"radio\" name=\"gender\" value=\"female\"> Female<br><br>"+
        		  "*Category:<br><br>" +
        		  "<select name=\"*category\">"+
                  "<option value=\"feedback\">Feedback</option>"+
                  "<option value=\"inquiry\">Inquiry</option>"+
                  "<option value=\"complaint\">Complaint</option>"+
                  "</select><br><br>"+
                  "*Message:<br><br>" +
                  
                  "<textarea name=\"message\" rows=\"10\" cols=\"30\">"+
                  "I like this website.Please keepup the good work.Cheers!"+
                  "</textarea><br><br>"+
        
                  "<input type=\"submit\" value=\"Submit\">"+
        		  "</form>");
        
        printWriter.println("Number of hits : " + counter);
       
    }
 
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
    	counter++;
    }
 
}
