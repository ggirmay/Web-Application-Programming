package Filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter(description = "ApplicationHitCountFilter", urlPatterns = { "", "/", "/*" })
public class ApplicationHitCountFilter implements Filter {
	private int hitCount;

    public ApplicationHitCountFilter() {
        
    }
	
	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		this.hitCount++;
		request.getServletContext().setAttribute("totalHitCount", this.hitCount);
		
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	
}
