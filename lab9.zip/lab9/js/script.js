$(document).ready(function(){
setInterval(() => {$("#dateTimeTicker").text(new Date());}, 1000);
    $.getJSON('js/studData.json', function(data){
        var res= ''

        $.each(data, function(key, value){
            res += '<tr>'
            res += '<td>' + value.studentId + '</td>'
            res += '<td>' + value.firstName + '</td>'
            res += '</tr>'
        })
        
        $('#jsonData').append(res)

        for(var i in localStorage){ 
            //console.log(localStorage[i]);
            $('#jsonData').append(localStorage.getItem(i))
        } 
    })
})


 


document.getElementById('registerForm').addEventListener('submit', function (event) {
    event.preventDefault()
    let temp= {}

    temp.studentId = document.getElementById('stuId').value
    temp.firstName = document.getElementById('fname').value

    let tempcombo = temp.studentId + ' ' + temp.firstName
    
    if(temp.studentId != "" && temp.firstName != ""){
        var res= ''
        res += '<tr>'
        res += '<td>' + res.studentId + '</td>'
        res += '<td>' + res.firstName + '</td>'
        res += '</tr>'
    }
    localStorage.setItem(stu.studentId,res)
    $('#jsonData').append(res)
    document.querySelector('#stuId').value = ''
    document.querySelector('#fname').value = ''
    
})
